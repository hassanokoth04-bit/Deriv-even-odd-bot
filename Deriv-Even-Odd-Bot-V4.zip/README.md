# Deriv Even/Odd Bot V4

GitHub Pages-ready dashboard for Deriv digit analysis.

## Files
- index.html
- style.css
- script.js

## Deployment
GitHub Pages should deploy from the repository's `main` branch and `/ (root)` folder.

## Important
This version is an analytical dashboard. It connects to Deriv WebSocket using a user-provided API token and displays live ticks/digits. It does not automatically place contracts and makes no guarantee of profitable predictions.

App ID configured in `script.js`:
34eUE5W4X4BBYRnAAoXWs
